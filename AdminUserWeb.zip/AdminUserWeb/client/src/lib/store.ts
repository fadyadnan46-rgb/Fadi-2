import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type Role = 'admin' | 'user';

export interface User {
  id: string;
  username: string;
  role: Role;
  name: string;
  email?: string;
  password?: string; // In real app this would be hashed
}

export interface Car {
  id: string;
  vin: string;
  lot: string;
  year: number;
  make: string;
  model: string;
  destination: string;
  hasTitle: boolean;
  hasKey: boolean;
  note: string;
  adminNote?: string;
  assignedToUserId?: string;
  
  // Logistics
  containerNumber?: string;
  bookingNumber?: string;
  etd?: string;
  eta?: string;
  
  // Photos
  loadingPhotos?: string[]; 
  unloadingPhotos?: string[]; 
  warehousePhotos?: string[];
  
  invoice?: string; 
}

// Configuration
export interface SystemConfig {
  makes: string[];
  models: Record<string, string[]>; 
  destinations: string[];
}

interface AppState {
  currentUser: User | null;
  users: User[];
  cars: Car[];
  config: SystemConfig;
  
  login: (username: string, password?: string) => boolean;
  logout: () => void;
  
  addUser: (user: Omit<User, 'id'>) => void;
  updateUser: (id: string, updates: Partial<User>) => void; // Added capability to edit user
  addCar: (car: Omit<Car, 'id'>) => void;
  updateCar: (id: string, updates: Partial<Car>) => void;
  deleteCar: (id: string) => void;
  deleteUser: (id: string) => void;
  
  // Config actions
  addMake: (make: string) => void;
  deleteMake: (make: string) => void;
  addModel: (make: string, model: string) => void;
  deleteModel: (make: string, model: string) => void;
  addDestination: (dest: string) => void;
  deleteDestination: (dest: string) => void;
  
  sendUpdateEmail: (carId: string) => void;
}

const INITIAL_USERS: User[] = [
  { id: '1', username: 'admin', role: 'admin', name: 'System Administrator', email: 'admin@example.com', password: 'password' },
  { id: '2', username: 'user1', role: 'user', name: 'John Doe', email: 'john@example.com', password: 'password' },
];

const INITIAL_CARS: Car[] = [
  { 
    id: '101', vin: '1HGCM82633A', lot: '45923', year: 2022, make: 'Honda', model: 'Accord', 
    destination: 'Lagos, Nigeria', hasTitle: true, hasKey: true, note: 'Minor scratch on bumper', 
    adminNote: 'Bought at auction for $12k', assignedToUserId: '2',
    loadingPhotos: [], unloadingPhotos: [],
    containerNumber: 'MSKU1234567', bookingNumber: 'BK987654321', etd: '2025-06-15', eta: '2025-07-20'
  },
];

const INITIAL_CONFIG: SystemConfig = {
  makes: ['Toyota', 'Honda', 'Nissan', 'Lexus', 'Mercedes-Benz', 'BMW', 'Ford', 'Hyundai', 'Kia'],
  models: {
    'Toyota': ['Camry', 'Corolla', 'RAV4', 'Highlander', 'Tacoma'],
    'Honda': ['Accord', 'Civic', 'CR-V', 'Pilot', 'Odyssey'],
    'Nissan': ['Altima', 'Rogue', 'Sentra', 'Pathfinder', 'Versa'],
  },
  destinations: ['Lagos, Nigeria', 'Accra, Ghana', 'Cotonou, Benin', 'Dubai, UAE', 'Tema, Ghana', 'Lome, Togo'],
};

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      currentUser: null,
      users: INITIAL_USERS,
      cars: INITIAL_CARS,
      config: INITIAL_CONFIG,

      login: (username, password) => {
        if (!password) return false;
        const user = get().users.find(u => u.username === username && u.password === password);
        if (user) {
          set({ currentUser: user });
          return true;
        }
        return false;
      },

      logout: () => set({ currentUser: null }),

      addUser: (user) => set((state) => ({
        users: [...state.users, { ...user, id: Math.random().toString(36).substr(2, 9) }]
      })),

      updateUser: (id, updates) => set((state) => ({
        users: state.users.map(u => u.id === id ? { ...u, ...updates } : u),
        // Also update current user if it's the one being edited
        currentUser: state.currentUser?.id === id ? { ...state.currentUser, ...updates } : state.currentUser
      })),

      addCar: (car) => set((state) => ({
        cars: [...state.cars, { ...car, id: Math.random().toString(36).substr(2, 9) }]
      })),

      updateCar: (id, updates) => set((state) => ({
        cars: state.cars.map(c => c.id === id ? { ...c, ...updates } : c)
      })),

      deleteCar: (id) => set((state) => ({
        cars: state.cars.filter(c => c.id !== id)
      })),

      deleteUser: (id) => set((state) => ({
        users: state.users.filter(u => u.id !== id)
      })),

      addMake: (make) => set((state) => ({
        config: { ...state.config, makes: [...state.config.makes, make] }
      })),
      deleteMake: (make) => set((state) => ({
        config: { ...state.config, makes: state.config.makes.filter(m => m !== make) }
      })),
      
      addModel: (make, model) => set((state) => {
        const currentModels = state.config.models[make] || [];
        return {
          config: { 
            ...state.config, 
            models: { ...state.config.models, [make]: [...currentModels, model] } 
          }
        };
      }),
      deleteModel: (make, model) => set((state) => {
        const currentModels = state.config.models[make] || [];
        return {
          config: { 
            ...state.config, 
            models: { ...state.config.models, [make]: currentModels.filter(m => m !== model) } 
          }
        };
      }),
      
      addDestination: (dest) => set((state) => ({
        config: { ...state.config, destinations: [...state.config.destinations, dest] }
      })),
      deleteDestination: (dest) => set((state) => ({
        config: { ...state.config, destinations: state.config.destinations.filter(d => d !== dest) }
      })),

      sendUpdateEmail: (carId) => {
        const car = get().cars.find(c => c.id === carId);
        const user = get().users.find(u => u.id === car?.assignedToUserId);
        if (car && user) {
          console.log(`MOCK EMAIL SENT TO: ${user.email}`);
        }
      }
    }),
    {
      name: 'app-storage-v3', // Bumped version
    }
  )
);
