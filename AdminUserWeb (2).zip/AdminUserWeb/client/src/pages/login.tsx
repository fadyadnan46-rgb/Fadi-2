import { useState } from "react";
import { useStore } from "@/lib/store";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useLanguage, t } from "@/lib/language-context";
import { Eye, EyeOff } from "lucide-react";
import { LanguageSelector } from "@/components/language-selector";
import logo from "@assets/logo_imresizer_(1)_1764805116719.jpg";
import backgroundImage from "@assets/Log-in_Background_1764800039054.jpg";

export default function LoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { login, initializeApp } = useStore();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { language } = useLanguage();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      const success = await login(username, password);
      if (success) {
        // Load all data after successful login
        await initializeApp();
        
        toast({
          title: t('welcome_back', language),
          description: t('successfully_logged_in', language),
        });
        setLocation("/");
      } else {
        toast({
          variant: "destructive",
          title: t('login_failed', language),
          description: t('invalid_credentials', language),
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: t('login_failed', language),
        description: t('invalid_credentials', language),
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div 
      className="min-h-screen h-screen w-full flex items-center justify-center relative overflow-hidden"
      style={{
        backgroundImage: `url(${backgroundImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      <div className="absolute inset-0 w-full h-full bg-black/40"></div>
      
      {/* Language Selector in top corner */}
      <div className="absolute top-4 right-4 z-20">
        <div className="bg-white/90 backdrop-blur-sm rounded-lg shadow-lg">
          <LanguageSelector />
        </div>
      </div>
      
      <Card className="w-full max-w-lg mx-4 shadow-2xl border-white/30 backdrop-blur-lg bg-white/20 relative z-10">
        <CardHeader className="space-y-3 text-center flex flex-col items-center pb-2">
          <div className="w-32 h-32 rounded-xl overflow-hidden flex items-center justify-center bg-white shadow-lg p-2">
             <img src={logo} alt="Al Khatu Al Naaqil" className="w-full h-full object-contain" />
          </div>
          <CardTitle className="text-2xl font-bold tracking-tight">{t('portal_access', language)}</CardTitle>
        </CardHeader>
        <CardContent className="pt-2">
          <form onSubmit={handleLogin} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="username" className="text-base">{t('username', language)}</Label>
              <Input 
                id="username" 
                placeholder={t('enter_username', language)}
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="bg-background/50 h-12 text-base"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-base">{t('password', language)}</Label>
              <div className="relative">
                <Input 
                  id="password" 
                  type={showPassword ? "text" : "password"}
                  placeholder={t('enter_password', language)}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-background/50 pr-12 h-12 text-base"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  data-testid="toggle-password-visibility"
                >
                  {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>
            <Button type="submit" className="w-full text-base font-medium h-12 mt-2" disabled={isLoading}>
              {isLoading ? t('signing_in', language) : t('sign_in', language)}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
