import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type Language = 'en' | 'ar';

interface LanguageStore {
  language: Language;
  setLanguage: (lang: Language) => void;
}

export const useLanguage = create<LanguageStore>()(
  persist(
    (set) => ({
      language: 'en',
      setLanguage: (lang) => set({ language: lang }),
    }),
    {
      name: 'language-storage',
    }
  )
);

export const t = (key: string, lang: Language): string => {
  const translations: Record<string, Record<Language, string>> = {
    'edit': { 'en': 'Edit', 'ar': 'تعديل' },
    'delete': { 'en': 'Delete', 'ar': 'حذف' },
    'language': { 'en': 'Language', 'ar': 'اللغة' },
    'english': { 'en': 'English', 'ar': 'English' },
    'arabic': { 'en': 'العربية', 'ar': 'العربية' },
  };
  return translations[key]?.[lang] || key;
};
