import { useStore } from "@/lib/store";
import { useState } from "react";
import { 
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Check, ChevronsUpDown } from "lucide-react";
import logo from "@assets/logo_1764504161984.png";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"

export function AddCarDialog() {
  const [open, setOpen] = useState(false);
  const { addCar, users, config } = useStore();
  const { toast } = useToast();

  // Local state for cascading make/model select
  const [selectedMake, setSelectedMake] = useState<string>("");
  const [selectedModel, setSelectedModel] = useState<string>("");
  
  // Popover states
  const [makeOpen, setMakeOpen] = useState(false);
  const [modelOpen, setModelOpen] = useState(false);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    addCar({
      vin: formData.get('vin') as string,
      lot: formData.get('lot') as string,
      year: Number(formData.get('year')),
      make: selectedMake,
      model: selectedModel,
      destination: formData.get('destination') as string,
      hasTitle: formData.get('hasTitle') === 'on',
      hasKey: formData.get('hasKey') === 'on',
      note: formData.get('note') as string,
      adminNote: formData.get('adminNote') as string,
      assignedToUserId: formData.get('assignedToUserId') as string,
      
      containerNumber: formData.get('containerNumber') as string,
      bookingNumber: formData.get('bookingNumber') as string,
      etd: formData.get('etd') as string,
      eta: formData.get('eta') as string,
    });

    toast({ title: "Car Added", description: "New vehicle has been added to the system." });
    setOpen(false);
    // Reset
    setSelectedMake("");
    setSelectedModel("");
  };

  const availableModels = selectedMake ? (config.models[selectedMake] || []) : [];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="lg" className="gap-2 bg-primary hover:bg-primary/90">
          <Plus className="w-5 h-5" /> Add Vehicle
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-4 mb-4">
            <div className="w-20 h-20 rounded-lg bg-white overflow-hidden flex items-center justify-center p-2 flex-shrink-0">
              <img src={logo} alt="ALKHAT ALNAQQIL" className="w-full h-full object-contain" />
            </div>
            <div>
              <DialogTitle className="text-2xl">Add New Vehicle</DialogTitle>
              <DialogDescription>Enter the vehicle details below.</DialogDescription>
            </div>
          </div>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          {/* Basic Info */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="vin">VIN #</Label>
              <Input id="vin" name="vin" required placeholder="1HG..." className="uppercase" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="lot">LOT #</Label>
              <Input id="lot" name="lot" required placeholder="459..." />
            </div>
            <div className="space-y-2">
              <Label htmlFor="year">Year</Label>
              <Input id="year" name="year" type="number" required min="1900" max="2026" defaultValue="2024" />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* SEARCHABLE MAKE */}
            <div className="space-y-2 flex flex-col">
              <Label>Make</Label>
              <Popover open={makeOpen} onOpenChange={setMakeOpen}>
                <PopoverTrigger asChild>
                  <Button variant="outline" role="combobox" aria-expanded={makeOpen} className="justify-between">
                    {selectedMake || "Select Make..."}
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="p-0">
                  <Command>
                    <CommandInput placeholder="Search make..." />
                    <CommandList>
                      <CommandEmpty>No make found.</CommandEmpty>
                      <CommandGroup>
                        {config.makes.map((make) => (
                          <CommandItem key={make} value={make} onSelect={(currentValue) => {
                            setSelectedMake(currentValue === selectedMake ? "" : currentValue);
                            setSelectedModel(""); // Reset model
                            setMakeOpen(false);
                          }}>
                            <Check className={cn("mr-2 h-4 w-4", selectedMake === make ? "opacity-100" : "opacity-0")} />
                            {make}
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
              <input type="hidden" name="make" value={selectedMake} required />
            </div>

            {/* SEARCHABLE MODEL */}
            <div className="space-y-2 flex flex-col">
              <Label>Model</Label>
              <Popover open={modelOpen} onOpenChange={setModelOpen}>
                <PopoverTrigger asChild>
                  <Button variant="outline" role="combobox" aria-expanded={modelOpen} className="justify-between" disabled={!selectedMake}>
                    {selectedModel || "Select Model..."}
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="p-0">
                  <Command>
                    <CommandInput placeholder="Search model..." />
                    <CommandList>
                      <CommandEmpty>No model found.</CommandEmpty>
                      <CommandGroup>
                        {availableModels.map((model) => (
                          <CommandItem key={model} value={model} onSelect={(currentValue) => {
                            setSelectedModel(currentValue === selectedModel ? "" : currentValue);
                            setModelOpen(false);
                          }}>
                            <Check className={cn("mr-2 h-4 w-4", selectedModel === model ? "opacity-100" : "opacity-0")} />
                            {model}
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
              <input type="hidden" name="model" value={selectedModel} required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="destination">Destination</Label>
              <select 
                id="destination" 
                name="destination" 
                className="flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                required
              >
                <option value="">Select Destination</option>
                {config.destinations.map(dest => (
                  <option key={dest} value={dest}>{dest}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Logistics Info */}
          <div className="border rounded-lg p-4 bg-muted/20 space-y-4">
            <h4 className="font-semibold text-sm text-muted-foreground mb-2">Logistics Information</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                 <Label htmlFor="containerNumber">Container #</Label>
                 <Input id="containerNumber" name="containerNumber" placeholder="MSKU..." className="uppercase" />
              </div>
              <div className="space-y-2">
                 <Label htmlFor="bookingNumber">Booking #</Label>
                 <Input id="bookingNumber" name="bookingNumber" placeholder="BK..." className="uppercase" />
              </div>
              <div className="space-y-2">
                 <Label htmlFor="etd">ETD (Estimated Time of Departure)</Label>
                 <Input id="etd" name="etd" type="date" />
              </div>
              <div className="space-y-2">
                 <Label htmlFor="eta">ETA (Estimated Time of Arrival)</Label>
                 <Input id="eta" name="eta" type="date" />
              </div>
            </div>
          </div>

          <div className="flex items-center gap-8">
            <div className="flex items-center space-x-2">
              <Checkbox id="hasTitle" name="hasTitle" />
              <Label htmlFor="hasTitle">Title Available</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox id="hasKey" name="hasKey" />
              <Label htmlFor="hasKey">Key Available</Label>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="assignedToUserId">Assign To User</Label>
            <select 
              name="assignedToUserId" 
              className="flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              required
            >
              <option value="">Select a User</option>
              {users.filter(u => u.role === 'user').map((user) => (
                <option key={user.id} value={user.id}>
                  {user.name} ({user.username})
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="note">Note (Visible to User)</Label>
            <Textarea id="note" name="note" placeholder="Any public notes..." />
          </div>

          <div className="space-y-2">
            <Label htmlFor="adminNote" className="text-primary">Admin Note (Internal Only)</Label>
            <Textarea id="adminNote" name="adminNote" placeholder="Private admin notes..." className="bg-primary/5 border-primary/20" />
          </div>

          <DialogFooter>
            <Button type="submit">Save Vehicle</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
