import { useStore } from "@/lib/store";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AddCarDialog } from "@/components/add-car-dialog";
import { Search, MapPin, Key, ImageIcon, Trash2, Edit } from "lucide-react";
import { useState, useMemo } from "react";
import { useLocation } from "wouter";

export default function UserDashboard() {
  const { cars, currentUser, deleteCar } = useStore();
  const [, setLocation] = useLocation();
  const [filters, setFilters] = useState({
    search: "",
    make: "all",
    year: "all",
    destination: "all",
  });

  const myCars = useMemo(() => {
    if (!currentUser) return [];
    if (currentUser.role === 'admin') return cars;
    return cars.filter(car => car.assignedToUserId === currentUser.id);
  }, [cars, currentUser]);

  const filteredCars = useMemo(() => {
    return myCars.filter(car => {
      const matchesSearch = 
        car.vin.toLowerCase().includes(filters.search.toLowerCase()) ||
        car.lot.toLowerCase().includes(filters.search.toLowerCase()) ||
        car.model.toLowerCase().includes(filters.search.toLowerCase());
      
      const matchesMake = filters.make === 'all' || car.make === filters.make;
      const matchesYear = filters.year === 'all' || car.year.toString() === filters.year;
      const matchesDestination = filters.destination === 'all' || car.destination === filters.destination;

      return matchesSearch && matchesMake && matchesYear && matchesDestination;
    });
  }, [myCars, filters]);

  const uniqueMakes = Array.from(new Set(myCars.map(c => c.make)));
  const uniqueYears = Array.from(new Set(myCars.map(c => c.year))).sort().reverse();
  const uniqueDestinations = Array.from(new Set(myCars.map(c => c.destination)));

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-start">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">My Garage</h1>
          <p className="text-muted-foreground">Manage and track your assigned vehicles.</p>
        </div>
        {currentUser?.role === 'admin' && <AddCarDialog />}
      </div>

      <Card className="bg-muted/30 shadow-none border-none">
        <CardContent className="p-4 md:p-6 space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <div className="space-y-2 col-span-full lg:col-span-1">
              <Label className="text-xs font-medium text-muted-foreground">Search</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input 
                  placeholder="VIN, Lot, Model..." 
                  className="pl-9 bg-background"
                  value={filters.search}
                  onChange={(e) => setFilters({...filters, search: e.target.value})}
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-xs font-medium text-muted-foreground">Make</Label>
              <Select 
                value={filters.make} 
                onValueChange={(val) => setFilters({...filters, make: val})}
              >
                <SelectTrigger className="bg-background">
                  <SelectValue placeholder="All Makes" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Makes</SelectItem>
                  {uniqueMakes.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-xs font-medium text-muted-foreground">Year</Label>
              <Select 
                value={filters.year} 
                onValueChange={(val) => setFilters({...filters, year: val})}
              >
                <SelectTrigger className="bg-background">
                  <SelectValue placeholder="All Years" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Years</SelectItem>
                  {uniqueYears.map(y => <SelectItem key={y} value={y.toString()}>{y}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-xs font-medium text-muted-foreground">Destination</Label>
              <Select 
                value={filters.destination} 
                onValueChange={(val) => setFilters({...filters, destination: val})}
              >
                <SelectTrigger className="bg-background">
                  <SelectValue placeholder="All Destinations" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Destinations</SelectItem>
                  {uniqueDestinations.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-2">
        {filteredCars.length === 0 ? (
           <div className="text-center py-12 text-muted-foreground">
             No vehicles found matching your criteria.
           </div>
        ) : (
          filteredCars.map((car) => {
            return (
              <Card key={car.id} className="group overflow-hidden hover:shadow-md transition-all duration-300 cursor-pointer hover:border-primary/50"
                onClick={() => setLocation(`/car?id=${car.id}`)}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex-1 grid grid-cols-1 md:grid-cols-5 gap-4">
                      <div>
                        <div className="text-xs text-muted-foreground mb-1">Vehicle</div>
                        <div className="font-semibold group-hover:text-primary transition-colors">{car.year} {car.make} {car.model}</div>
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground mb-1">VIN</div>
                        <div className="font-mono text-sm font-medium">{car.vin}</div>
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground mb-1">LOT</div>
                        <div className="font-mono text-sm font-medium">{car.lot}</div>
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground mb-1">Destination</div>
                        <div className="text-sm flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-primary" />
                          {car.destination}
                        </div>
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground mb-1">Status</div>
                        <div className="flex gap-2">
                          <Badge variant={car.hasTitle ? "default" : "destructive"} className="text-[10px]">
                            {car.hasTitle ? "TITLE OK" : "NO TITLE"}
                          </Badge>
                          <Badge variant={car.hasKey ? "default" : "destructive"} className="text-[10px]">
                            {car.hasKey ? "KEY" : "NO KEY"}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    {currentUser?.role === 'admin' && (
                      <Button variant="ghost" size="sm" className="h-8 px-2 gap-1 text-destructive hover:text-destructive hover:bg-destructive/10" onClick={(e) => {
                        e.stopPropagation();
                        deleteCar(car.id);
                      }}>
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
}
