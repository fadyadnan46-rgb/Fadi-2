import { useStore } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { EditUserDialog, AddUserDialog } from "@/components/add-user-dialog";
import usersIcon from "@/assets/users-icon.png";

export default function UsersPage() {
  const { currentUser, users } = useStore();

  if (currentUser?.role !== 'admin') {
    return (
       <div className="flex flex-col items-center justify-center h-[60vh] space-y-4">
         <h1 className="text-2xl font-bold text-destructive">Access Denied</h1>
         <p className="text-muted-foreground">You do not have permission to view this page.</p>
       </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Users</h1>
          <p className="text-muted-foreground mt-2">Manage system users and their roles.</p>
        </div>
        <AddUserDialog />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {users.map((user) => (
          <Card key={user.id}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {user.name}
              </CardTitle>
              <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center">
                <img src={usersIcon} alt="User" className="h-5 w-5" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{user.username}</div>
              <div className="flex justify-between items-end mt-2">
                 <p className="text-xs text-muted-foreground capitalize">
                   Role: {user.role}
                 </p>
                 <EditUserDialog user={user} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
