import { useStore } from "@/lib/store";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Plus, Trash2 } from "lucide-react";
import { useState } from "react";

export default function AdminSettings() {
  const { config, addMake, deleteMake, addModel, deleteModel, addDestination, deleteDestination, currentUser } = useStore();
  
  const [newMake, setNewMake] = useState("");
  const [newModel, setNewModel] = useState("");
  const [selectedMakeForModel, setSelectedMakeForModel] = useState("");
  const [newDest, setNewDest] = useState("");

  if (currentUser?.role !== 'admin') {
    return (
       <div className="flex flex-col items-center justify-center h-[60vh] space-y-4">
         <h1 className="text-2xl font-bold text-destructive">Access Denied</h1>
         <p className="text-muted-foreground">You do not have permission to view this page.</p>
       </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">System Settings</h1>
        <p className="text-muted-foreground mt-2">Manage system configurations.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Makes */}
        <Card>
           <CardHeader>
              <CardTitle className="text-base">Vehicle Makes</CardTitle>
              <CardDescription>Manage manufacturer list</CardDescription>
           </CardHeader>
           <CardContent className="space-y-4">
              <div className="flex gap-2">
                 <Input 
                    placeholder="New Make" 
                    value={newMake} 
                    onChange={(e) => setNewMake(e.target.value)} 
                 />
                 <Button size="icon" onClick={() => {if(newMake) {addMake(newMake); setNewMake("");}}}>
                    <Plus className="w-4 h-4" />
                 </Button>
              </div>
              <div className="h-[200px] overflow-y-auto space-y-1 border rounded-md p-2">
                 {config.makes.map(make => (
                    <div key={make} className="flex items-center justify-between text-sm p-2 hover:bg-muted rounded-sm group">
                       <span>{make}</span>
                       <Trash2 
                          className="w-4 h-4 text-muted-foreground hover:text-destructive cursor-pointer opacity-0 group-hover:opacity-100"
                          onClick={() => deleteMake(make)} 
                       />
                    </div>
                 ))}
              </div>
           </CardContent>
        </Card>

        {/* Models */}
        <Card>
           <CardHeader>
              <CardTitle className="text-base">Vehicle Models</CardTitle>
              <CardDescription>Models for selected make</CardDescription>
           </CardHeader>
           <CardContent className="space-y-4">
              <div className="space-y-2">
                 <Label className="text-xs">Select Make</Label>
                 <select 
                    className="w-full p-2 border rounded-md bg-background text-sm"
                    value={selectedMakeForModel}
                    onChange={(e) => setSelectedMakeForModel(e.target.value)}
                 >
                    <option value="">Select Make...</option>
                    {config.makes.map(m => <option key={m} value={m}>{m}</option>)}
                 </select>
              </div>
              <div className="flex gap-2">
                 <Input 
                    placeholder="New Model" 
                    value={newModel} 
                    onChange={(e) => setNewModel(e.target.value)}
                    disabled={!selectedMakeForModel}
                 />
                 <Button size="icon" disabled={!selectedMakeForModel} onClick={() => {if(newModel) {addModel(selectedMakeForModel, newModel); setNewModel("");}}}>
                    <Plus className="w-4 h-4" />
                 </Button>
              </div>
              <div className="h-[130px] overflow-y-auto space-y-1 border rounded-md p-2">
                 {(config.models[selectedMakeForModel] || []).map(model => (
                    <div key={model} className="flex items-center justify-between text-sm p-2 hover:bg-muted rounded-sm group">
                       <span>{model}</span>
                       <Trash2 
                          className="w-4 h-4 text-muted-foreground hover:text-destructive cursor-pointer opacity-0 group-hover:opacity-100"
                          onClick={() => deleteModel(selectedMakeForModel, model)} 
                       />
                    </div>
                 ))}
              </div>
           </CardContent>
        </Card>

        {/* Destinations */}
        <Card>
           <CardHeader>
              <CardTitle className="text-base">Destinations</CardTitle>
              <CardDescription>Shipping locations</CardDescription>
           </CardHeader>
           <CardContent className="space-y-4">
              <div className="flex gap-2">
                 <Input 
                    placeholder="City, Country" 
                    value={newDest} 
                    onChange={(e) => setNewDest(e.target.value)} 
                 />
                 <Button size="icon" onClick={() => {if(newDest) {addDestination(newDest); setNewDest("");}}}>
                    <Plus className="w-4 h-4" />
                 </Button>
              </div>
              <div className="h-[200px] overflow-y-auto space-y-1 border rounded-md p-2">
                 {config.destinations.map(dest => (
                    <div key={dest} className="flex items-center justify-between text-sm p-2 hover:bg-muted rounded-sm group">
                       <span>{dest}</span>
                       <Trash2 
                          className="w-4 h-4 text-muted-foreground hover:text-destructive cursor-pointer opacity-0 group-hover:opacity-100"
                          onClick={() => deleteDestination(dest)} 
                       />
                    </div>
                 ))}
              </div>
           </CardContent>
        </Card>
      </div>
    </div>
  );
}
